package admin.module;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="admin_source")
public class Admin {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY ) 
	//variables
	private int adminId;
	private String username;
	private int password;
	
	
	//Default constructor
	public Admin() {
		super();
	}


	
	//parameterized constructor
	public Admin(int adminId, String username, int password) {
		super();
		this.adminId = adminId;
		this.username = username;
		this.password = password;
	}


	//Getter and setter
	public int getAdminId() {
		return adminId;
	}



	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}



	public String getUserName() {
		return username;
	}



	public void setUserName(String username) {
		this.username = username;
	}



	public int getPassword() {
		return password;
	}



	public void setPassword(int password) {
		this.password = password;
	}
	
	
	//String Representation
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", username=" + username + ", password=" + password + "]";
	}

	
    
	
}