package admin.module;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("admin_source")

public class AdminController {
	
	@Autowired
	
	private AdminService adminService;
	
	@GetMapping
	public List<Admin> getAllAdmin()
	{
		return adminService.getAllAdmin();
	}
	@GetMapping("/{id}")
	public ResponseEntity<Admin> getAdminById(@PathVariable int id)
	{
		Admin admin = adminService.getAdminById(id);
		
		if(admin != null)
		{
			return ResponseEntity.ok(admin);
 	}
	
	else
	{
		return ResponseEntity.notFound().build();
	}
		
	}
	
	@PostMapping
	public Admin createAdmin(@RequestBody Admin admin)
	{
		return adminService.save(admin);
	}
	@PutMapping("/{id}")
	public ResponseEntity<Admin> updateAdmin(@PathVariable int id,@RequestBody Admin adminDetails)
	{
		Admin admin = adminService.getAdminById(id);
				
		if(admin != null)
		{
			admin.setUserName(adminDetails.getUserName());
			admin.setPassword(adminDetails.getPassword());
			
			Admin updatedAdmin = adminService.updateAdmin(admin);
			return ResponseEntity.ok(updatedAdmin);
		}
		
		else
		{
			return ResponseEntity.notFound().build();
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteAdmin(@PathVariable int id)
	{
		Admin admin = adminService.getAdminById(id);
				
		if(admin != null)
		{
			
			 adminService.deleteAdmin(id);
			return ResponseEntity.ok().build();
		}
		
		else
		{
			return ResponseEntity.notFound().build();
		}
	}

}
