package admin.module;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service

public class AdminService {
	
	@Autowired
	private AdminRepository adminRepository;
	
	
    //All admin retrieval
	public List<Admin> getAllAdmin() {
		// TODO Auto-generated method stub
		return adminRepository.findAll();
	}
    //specific id data retrieval
	public Admin getAdminById(int id) {
		// TODO Auto-generated method stub
		return adminRepository.findById(id).orElse(null);
	}
	//creation of data
	public Admin save(Admin admin) {
		// TODO Auto-generated method stub
		return adminRepository.save(admin);
	}
	//update of data
	public Admin updateAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminRepository.save(admin);
	}
	//deletion of data
	public void deleteAdmin(int id) {
		// TODO Auto-generated method stub
		adminRepository.deleteById(id);
	}

}
