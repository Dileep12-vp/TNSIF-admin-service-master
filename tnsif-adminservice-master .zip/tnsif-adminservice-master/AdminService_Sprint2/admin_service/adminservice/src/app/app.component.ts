import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AdminService} from './admin.service'; // Import your CollegeService
import { Admin } from './admin.model'; // Assuming you've defined the model

declare var bootstrap: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})




export class AppComponent implements OnInit {
  title = 'adminservice';
  adminDetails: Admin[] = [];  // Make sure it's an array

  // Model structure for the admin to be updated
  adminToUpdate: Admin = {
    adminId: 0,
    username: '',
    password: ''
  };

  constructor(private adminService: AdminService) {}

  ngOnInit() {
    this.getAllAdmin();
  }

  // Fetch all admins from the backend
  getAllAdmin() {
    this.adminService.getAllAdmin().subscribe(
      (data: Admin[]) => {
        this.adminDetails = Array.isArray(data) ? data : []; // Ensure it's an array
      },
      (err: any) => console.error('Error fetching admin:', err)
    );
  }

  // Register a new admin
  register(registerForm: NgForm) {
    if (registerForm.invalid) return;

    // Pass the form values to add a new admin
    this.adminService.createAdmin(registerForm.value).subscribe(
      (response) => {
        registerForm.reset();
        this.getAllAdmin();
      },
      (error) => {
        console.error('Error adding admin:', error);
      }
    );
  }

  // Open the edit form and pre-fill with current college data
  edit(admin: Admin) {
    this.adminToUpdate = { ...admin };
  }

  // Update the admin data
  updateAdmin() {
    if (!this.adminToUpdate.adminId) return;

    this.adminService.updateAdmin(this.adminToUpdate).subscribe(
      (response: any) => {
        this.getAllAdmin();
        this.closeModal();
      },
      (error: any) => {
        console.error('Error updating admin :', error);
      }
    );
  }

  // Delete a admin
  deleteAdmin(admin: Admin) {
    this.adminService.deleteAdmin(admin.adminId).subscribe(
      () => this.getAllAdmin(),
      (err: any) => console.error('Error deleting admin:', err)
    );
  }

  // Close the modal after update
  closeModal() {
    const modalElement = document.getElementById('exampleModal');
    if (modalElement) {
      const modal = new bootstrap.Modal(modalElement);
      modal.hide();
    }
  }
}
