export interface Admin {
  adminId: number,
  username: string,
  password: string  // Match backend field
  }