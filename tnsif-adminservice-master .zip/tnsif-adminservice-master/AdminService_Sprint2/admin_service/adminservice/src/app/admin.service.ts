import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Admin } from './admin.model';  // Assuming you have a admin model

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private API = 'http://localhost:8082/admin_source';  // Update with your backend API URL

  constructor(private http: HttpClient) { }

  // Add a new admin
  createAdmin(admin:any): Observable<any> {
    return this.http.post(this.API,admin);
  }
  
  // Fetch all admin details
  getAllAdmin(): Observable<Admin[]> {
    return this.http.get<Admin[]>(this.API);
  }

  // Update a admin
  updateAdmin(admin:any): Observable<any> {
    return this.http.put(`${this.API}/${admin.adminId}`, admin);
  }

  // Delete a admin
  deleteAdmin(adminId: number): Observable<any> {
    return this.http.delete(`${this.API}/${adminId}`);
  }
}
